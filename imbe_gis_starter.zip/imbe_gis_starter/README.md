# GIS Starter Kit — Imbé / Sistema Tramandaí–Imbé

Este pacote foi montado para iniciar um SIG/QGIS do teu levantamento ecológico costeiro.

## Estrutura sugerida do projeto
- `data_raw/` → bases oficiais baixadas de órgãos públicos
- `data_work/` → camadas recortadas e editadas
- `outputs/` → mapas exportados, figuras e layouts
- `templates/` → tabelas e esquemas de atributos

## Camadas-base recomendadas
1. Limite municipal de Imbé (IBGE)
2. Hidrografia / canais / drenagem (SEMA RS / FEPAM / Dados RS)
3. Uso e cobertura da terra (MapBiomas)
4. Pontos de ocorrência de fauna, flora e funga
5. Zonas ecológicas: marinha, lagunar, estuarina, urbana verde, microecossistemas

## CRS recomendado
- SIRGAS 2000 / UTM zone 22S
- EPSG:31982

## Fluxo no QGIS
1. Criar projeto em EPSG:31982
2. Carregar limite municipal e hidrografia
3. Criar camada de pontos a partir de `templates/observacoes_registro.csv`
4. Adicionar fotos como evidência no atributo `evidencia_foto`
5. Criar simbologia por grupo biológico:
   - Fauna
   - Flora
   - Funga
   - Impacto / educação ambiental
6. Gerar layout final com:
   - título
   - legenda
   - escala gráfica
   - norte
   - fonte dos dados

## Campos essenciais para a camada de observações
- id
- grupo
- subgrupo
- nome_cientifico
- nome_comum
- municipio
- local_sistema
- habitat
- data_obs
- latitude
- longitude
- precisao_m
- metodo
- evidencia_foto
- observacoes
- confianca_id

## Sugestão de zonas ecológicas
- Praia oceânica
- Margem lagunar
- Estuário / pesca
- Córrego urbano
- Área verde urbana
- Microhabitat de decomposição

## Produto final sugerido
- 1 mapa geral do sistema
- 1 mapa de fauna
- 1 mapa de flora/funga
- 1 mapa de conflitos e educação ambiental
